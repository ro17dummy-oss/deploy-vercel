/**
 * Created by PhpStorm.
 * @author: Monstr
 * @link http://mmws.ru/
 *
 * @version  2.4.2
 * @licence MIT license
 *
 * Date: 12.10.2019
 * Time: 21:26
 */
(function (k) {
    var u = {}, t = null, v = k("<div />", {id: "aiondb-viewer"}).bind({
        mouseleave: function (h) {
            h.shiftKey || k(this).removeData("aiondb").hide().empty()
        }
    }), w = function (h, b) {
        this.links = {};
        this.query = {};
        this._data = {};
        this._show = [];
        this.opt = k.extend({}, this.defaults, b);
        this.opt.iconSize = Math.max(18, Math.min(40, this.opt.iconSize));
        this.opt.domain = "string" === typeof this.opt.domain ? [this.opt.domain] : this.opt.domain;
        var a = this;
        a.elements = h.find("a[href]").filter(function () {
            if (!("host" in this || 0 > k.inArray(this.host,
                a.opt.domain)) && "pathname" in this) return !1;
            var b = /^\/[info\/]*?(items|skills|npc|transform|quests)\/([a-z\/]*?)([0-9{1,}]+)$/ig.exec(this.pathname);
            if (!b) return !1;
            a._push(this, b);
            return !0
        });
        0 < a.elements.length && a._start()
    }, x = function (h, b, a) {
        var m = this;
        m._adb = h;
        k.each(a, function (a) {
            a in m && k.isFunction(m[a]) && b in h.links && a in h.links[b] && m[a].call(m, this, h.links[b][a]);
            "style" === a && m.style.call(m, this)
        })
    }, r = function (h, b, a) {
        this._adb = h;
        this.link = b;
        this.item = a;
        this.target = v;
        this.hash = y(a);
        var m = this;
        k(this.link).bind("mousewheel.aiondb", function (a, b) {
            return m.tab(a, b)
        });
        k(this.link).bind("mouseenter.aiondb", function (a) {
            m.show(a)
        });
        k(this.link).bind("mousemove.aiondb", function (a) {
            m.move(a)
        });
        k(this.link).bind("mouseleave.aiondb", function (a) {
            m.hide(a)
        })
    }, y = function (h, b, a) {
        "string" !== typeof h && (h = JSON.stringify(h));
        var k = function (a, b) {
                var d = (a & 65535) + (b & 65535);
                return (a >> 16) + (b >> 16) + (d >> 16) << 16 | d & 65535
            }, l = function (a, b, d, c, e, f) {
                a = k(k(b, a), k(c, f));
                return k(a << e | a >>> 32 - e, d)
            },
            n = function (a, b, d, c, e, f, g) {
                return l(b & d | ~b & c, a, b, e, f, g)
            }, p = function (a, b, d, c, e, f, g) {
                return l(b & c | d & ~c, a, b, e, f, g)
            }, q = function (a, b, d, c, e, f, g) {
                return l(d ^ (b | ~c), a, b, e, f, g)
            }, r = function (a, b) {
                a[b >> 5] |= 128 << b % 32;
                a[(b + 64 >>> 9 << 4) + 14] = b;
                var d, c = 1732584193, e = -271733879, f = -1732584194, g = 271733878;
                for (d = 0; d < a.length; d += 16) {
                    var h = c;
                    var m = e;
                    var A = f;
                    var z = g;
                    c = n(c, e, f, g, a[d], 7, -680876936);
                    g = n(g, c, e, f, a[d + 1], 12, -389564586);
                    f = n(f, g, c, e, a[d + 2], 17, 606105819);
                    e = n(e, f, g, c, a[d + 3], 22, -1044525330);
                    c = n(c, e, f, g, a[d + 4], 7, -176418897);
                    g = n(g, c, e, f, a[d +
                    5], 12, 1200080426);
                    f = n(f, g, c, e, a[d + 6], 17, -1473231341);
                    e = n(e, f, g, c, a[d + 7], 22, -45705983);
                    c = n(c, e, f, g, a[d + 8], 7, 1770035416);
                    g = n(g, c, e, f, a[d + 9], 12, -1958414417);
                    f = n(f, g, c, e, a[d + 10], 17, -42063);
                    e = n(e, f, g, c, a[d + 11], 22, -1990404162);
                    c = n(c, e, f, g, a[d + 12], 7, 1804603682);
                    g = n(g, c, e, f, a[d + 13], 12, -40341101);
                    f = n(f, g, c, e, a[d + 14], 17, -1502002290);
                    e = n(e, f, g, c, a[d + 15], 22, 1236535329);
                    c = p(c, e, f, g, a[d + 1], 5, -165796510);
                    g = p(g, c, e, f, a[d + 6], 9, -1069501632);
                    f = p(f, g, c, e, a[d + 11], 14, 643717713);
                    e = p(e, f, g, c, a[d], 20, -373897302);
                    c = p(c, e,
                        f, g, a[d + 5], 5, -701558691);
                    g = p(g, c, e, f, a[d + 10], 9, 38016083);
                    f = p(f, g, c, e, a[d + 15], 14, -660478335);
                    e = p(e, f, g, c, a[d + 4], 20, -405537848);
                    c = p(c, e, f, g, a[d + 9], 5, 568446438);
                    g = p(g, c, e, f, a[d + 14], 9, -1019803690);
                    f = p(f, g, c, e, a[d + 3], 14, -187363961);
                    e = p(e, f, g, c, a[d + 8], 20, 1163531501);
                    c = p(c, e, f, g, a[d + 13], 5, -1444681467);
                    g = p(g, c, e, f, a[d + 2], 9, -51403784);
                    f = p(f, g, c, e, a[d + 7], 14, 1735328473);
                    e = p(e, f, g, c, a[d + 12], 20, -1926607734);
                    c = l(e ^ f ^ g, c, e, a[d + 5], 4, -378558);
                    g = l(c ^ e ^ f, g, c, a[d + 8], 11, -2022574463);
                    f = l(g ^ c ^ e, f, g, a[d + 11], 16, 1839030562);
                    e = l(f ^ g ^ c, e, f, a[d + 14], 23, -35309556);
                    c = l(e ^ f ^ g, c, e, a[d + 1], 4, -1530992060);
                    g = l(c ^ e ^ f, g, c, a[d + 4], 11, 1272893353);
                    f = l(g ^ c ^ e, f, g, a[d + 7], 16, -155497632);
                    e = l(f ^ g ^ c, e, f, a[d + 10], 23, -1094730640);
                    c = l(e ^ f ^ g, c, e, a[d + 13], 4, 681279174);
                    g = l(c ^ e ^ f, g, c, a[d], 11, -358537222);
                    f = l(g ^ c ^ e, f, g, a[d + 3], 16, -722521979);
                    e = l(f ^ g ^ c, e, f, a[d + 6], 23, 76029189);
                    c = l(e ^ f ^ g, c, e, a[d + 9], 4, -640364487);
                    g = l(c ^ e ^ f, g, c, a[d + 12], 11, -421815835);
                    f = l(g ^ c ^ e, f, g, a[d + 15], 16, 530742520);
                    e = l(f ^ g ^ c, e, f, a[d + 2], 23, -995338651);
                    c = q(c, e, f, g, a[d], 6, -198630844);
                    g = q(g,
                        c, e, f, a[d + 7], 10, 1126891415);
                    f = q(f, g, c, e, a[d + 14], 15, -1416354905);
                    e = q(e, f, g, c, a[d + 5], 21, -57434055);
                    c = q(c, e, f, g, a[d + 12], 6, 1700485571);
                    g = q(g, c, e, f, a[d + 3], 10, -1894986606);
                    f = q(f, g, c, e, a[d + 10], 15, -1051523);
                    e = q(e, f, g, c, a[d + 1], 21, -2054922799);
                    c = q(c, e, f, g, a[d + 8], 6, 1873313359);
                    g = q(g, c, e, f, a[d + 15], 10, -30611744);
                    f = q(f, g, c, e, a[d + 6], 15, -1560198380);
                    e = q(e, f, g, c, a[d + 13], 21, 1309151649);
                    c = q(c, e, f, g, a[d + 4], 6, -145523070);
                    g = q(g, c, e, f, a[d + 11], 10, -1120210379);
                    f = q(f, g, c, e, a[d + 2], 15, 718787259);
                    e = q(e, f, g, c, a[d + 9], 21, -343485551);
                    c = k(c, h);
                    e = k(e, m);
                    f = k(f, A);
                    g = k(g, z)
                }
                return [c, e, f, g]
            }, t = function (a) {
                var b, d = "", c = 32 * a.length;
                for (b = 0; b < c; b += 8) d += String.fromCharCode(a[b >> 5] >>> b % 32 & 255);
                return d
            }, u = function (a) {
                var b, d = [];
                d[(a.length >> 2) - 1] = void 0;
                for (b = 0; b < d.length; b += 1) d[b] = 0;
                var c = 8 * a.length;
                for (b = 0; b < c; b += 8) d[b >> 5] |= (a.charCodeAt(b / 8) & 255) << b % 32;
                return d
            }, v = function (a) {
                return t(r(u(a), 8 * a.length))
            }, w = function (a) {
                var b = "", d;
                for (d = 0; d < a.length; d += 1) {
                    var c = a.charCodeAt(d);
                    b += "0123456789abcdef".charAt(c >>> 4 & 15) + "0123456789abcdef".charAt(c &
                        15)
                }
                return b
            }, x = function (a, b) {
                var d = unescape(encodeURIComponent(a)), c = unescape(encodeURIComponent(b)), e = u(d), f = [], g = [];
                f[15] = g[15] = void 0;
                16 < e.length && (e = r(e, 8 * d.length));
                for (d = 0; 16 > d; d += 1) f[d] = e[d] ^ 909522486, g[d] = e[d] ^ 1549556828;
                c = r(f.concat(u(c)), 512 + 8 * c.length);
                return t(r(g.concat(c), 640))
            };
        return b ? a ? x(b, h) : w(x(b, h)) : a ? v(unescape(encodeURIComponent(h))) : w(v(unescape(encodeURIComponent(h))))
    };
    w.prototype = {
        defaults: {
            domain: ["kb.aionempire.com"], addIcon: !0, iconSize: 25, setColor: !0, fontWeight: "bold",
            background: "transparent", replaceText: !0, includeStyle: !0
        }, _push: function (h, b) {
            var a = h.host, m = this.query, l = this.links;
            a in m || (m[a] = {});
            a in l || (l[a] = {});
            "skills" === b[1] ? (b[2] = b[2].replace("/", ""), l[a].skills = l[a].skills || {}, m[a].skills = m[a].skills || {}, b[2] in l[a].skills ? b[3] in l[a].skills[b[2]] || (l[a].skills[b[2]][b[3]] = []) : (l[a].skills[b[2]] = {}, m[a].skills[b[2]] = [], l[a].skills[b[2]][b[3]] = []), l[a].skills[b[2]][b[3]].push(h), 0 > k.inArray(b[3], m[a].skills[b[2]]) && m[a].skills[b[2]].push(b[3])) : (l[a][b[1]] =
                l[a][b[1]] || {}, m[a][b[1]] = m[a][b[1]] || [], l[a][b[1]][b[3]] = l[a][b[1]][b[3]] || [], l[a][b[1]][b[3]].push(h), 0 > k.inArray(b[3], m[a][b[1]]) && m[a][b[1]].push(b[3]))
        }, _start: function () {
            var h = this;
            k.each(h.query, function (b) {
                this.style = h.opt.includeStyle ? 1 : 0;
                k.ajax("https://" + b + "/syndication/list/?lang="+h.opt.lang, {
                    data: this,
                    type: "get",
                    dataType: "json",
                    success: function (a) {
                        h._show.push(new x(h, b, a))
                    }
                })
            })
        }
    };
    x.prototype = {
        npc: function (h, b) {
            var a = this._adb;
            k.each(b, function (b) {
                if (b in h) {
                    var l = h[b];
                    k.each(this, function () {
                        var b = k(this).addClass("aiondb-link").data("aiondb", {
                            type: "npc",
                            viewer: new r(a, this, l)
                        }).css({fontWeight: a.opt.fontWeight, backgroundColor: a.opt.background});
                        a.opt.setColor && b.addClass("aiondb-npc-color aiondb-tribe-" + l.tribe);
                        if (a.opt.addIcon || a.opt.replaceText) {
                            var h = k("<span />", {
                                "class": "aiondb-link-icon",
                                css: {width: a.opt.iconSize, height: a.opt.iconSize}
                            }).append(k("<img />", {src: "//" + this.host + "/upload/images/icon/emblem/icon_emblem_" + l.disk_type + ".png"}));
                            a.opt.addIcon && a.opt.replaceText ? b.html(h.add(k("<span />",
                                {text: l.desc}))) : a.opt.replaceText ? b.html(k("<span />", {text: l.desc})) : h.prependTo(b)
                        }
                    })
                }
            })
        }, items: function (h, b) {
            var a = this._adb;
            k.each(b, function (b) {
                if (b in h) {
                    var l = h[b];
                    k.each(this, function () {
                        var b = k(this).addClass("aiondb-link").data("aiondb", {
                            type: "items",
                            viewer: new r(a, this, l)
                        }).css({fontWeight: a.opt.fontWeight, backgroundColor: a.opt.background});
                        a.opt.setColor && b.addClass("aiondb-rank-" + l.quality);
                        if (a.opt.addIcon || a.opt.replaceText) {
                            var h = k("<span />", {
                                "class": "aiondb-link-icon", css: {
                                    width: a.opt.iconSize,
                                    height: a.opt.iconSize
                                }
                            }).append(k("<img />", {src: "//" + this.host + "/assets/images/icons/" + l.icon_name.toLowerCase() + ".jpg"}));
                            l.disuse && k(h).addClass("disuse");
                            a.opt.addIcon && a.opt.replaceText ? b.html(h.add(k("<span />", {text: l.desc}))) : a.opt.replaceText ? b.html(k("<span />", {text: l.desc})) : h.prependTo(b)
                        }
                    })
                }
            })
        }, skills: function (h, b) {
            var a = this._adb;
            k.each(b, function (m) {
                m in b && k.each(b[m], function (b) {
                    if (b in h) {
                        var l = h[b];
                        k.each(this, function () {
                            var b = k(this).addClass("aiondb-link").data("aiondb", {
                                type: "skills",
                                viewer: new r(a, this, l)
                            }).css({fontWeight: a.opt.fontWeight, backgroundColor: a.opt.background});
                            a.opt.setColor && b.addClass("aiondb-default-color");
                            if (a.opt.addIcon || a.opt.replaceText) {
                                var h = k("<span />", {
                                    "class": "aiondb-link-icon",
                                    css: {width: a.opt.iconSize, height: a.opt.iconSize}
                                }).append(k("<img />", {src: "//" + this.host + "/upload/images/icon/skill/" + l.skillicon_name + ".png"}));
                                a.opt.addIcon && a.opt.replaceText ? b.html(h.add(k("<span />", {text: l.desc}))) : a.opt.replaceText ? b.html(k("<span />", {text: l.desc})) :
                                    h.prependTo(b)
                            }
                        })
                    }
                })
            })
        }, quests: function (h, b) {
            var a = this._adb;
            k.each(b, function (b) {
                console.log(b, h);
                if (b in h) {
                    var l = h[b];
                    k.each(this, function () {
                        var b = k(this).addClass("aiondb-link").data("aiondb", {
                            type: "quests",
                            viewer: new r(a, this, l)
                        }).css({fontWeight: a.opt.fontWeight, backgroundColor: a.opt.background});
                        console.log(b);
                        a.opt.setColor && b.addClass("aiondb-quest-category-" + l.type);
                        if (a.opt.addIcon || a.opt.replaceText) {
                            var h = k("<span />", {
                                "class": "aiondb-link-icon",
                                css: {width: a.opt.iconSize, height: a.opt.iconSize}
                            }).append(k("<img />",
                                {src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAAH7+Yj7AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAJZSURBVHjaYsnKKw558ORVFwMSYHnw5FXXpTNHGVAEGbAA4gUBAAAA//9i8QqKvYchiG4JAwMDA8ufv38YWJgRpvz795cEiwAAAAD//2LxCoq9d/roXgZGRiYGfICFgYGBgZmFBcUudIDTbqLdg1Phv7//GP4x/sWp6M+fvwwAAAAA///CGmpYTTxxaBcDCwsrYYVMTMwMLCzMDExMzPh9/e/fXwYmJg4q+3ooKPz37y9eRUxMzAwAAAAA//9i8QqKvXfi0C4GagBmZmaIzUxMzAwsrPiTJDEAnmwhXmGhiiupYwpS+FLNQKq7cKQbyMzMzMDEyMjw5+8f8g1iZmHgFxJmAAAAAP//IroMIwZIiQt3sJw5tp/hz5/fVDHQws6tguXfv38MTEzMDExMTGQb9P//P9QwZGJiYmBjY6NuToEUysyDJ9nAHEM1A2FJbjQvjxo4aiBJBv77/5+BiRoGMjJCyjMmRmaCjSGiDGRn52D49esXw7///8kvaRgZGViYIS1cAAAAAP//YvEKir13+/pFho/v38FL379//zIMBGBiYmZgZISw+fiFGNR1DCFx8uHdmwFzFLZahIGBgeHTx3eIRAOLDWZmZgZGRiYGJmamgXXoX7Q6lJER4ThCnRa6OBCpv4YSgoyM1Mt+1C8X/v2FN23QO9f0Tof//v9nYILmFhZc2XzQheBgBaMOHHXgqANHHTjqwKHqQFiHnhrNbJLqYrSWOLy5BWtN//vLwPCPgYGBiZmJ4R8Fw0Dktv8YoHYzQxsrLIJ83PNMrZ2TBmP0CgvwTAcMAMs0svYF5MmLAAAAAElFTkSuQmCC"}));
                            a.opt.addIcon && a.opt.replaceText ? b.html(h.add(k("<span />", {text: l.desc}))) : a.opt.replaceText ? b.html(k("<span />", {text: l.desc})) : h.prependTo(b)
                        }
                    })
                }
            })
        }, transform: function (h, b) {
            var a = this._adb;
            k.each(b, function (b) {
                if (b in h) {
                    var l = h[b];
                    k.each(this, function () {
                        var b = k(this).addClass("aiondb-link").data("aiondb", {
                            type: "transform",
                            viewer: new r(a, this, l)
                        }).css({fontWeight: a.opt.fontWeight, backgroundColor: a.opt.background});
                        a.opt.setColor && b.addClass("aiondb-transform-rank-0" + l.grade);
                        if (a.opt.addIcon ||
                            a.opt.replaceText) {
                            var h = k("<span />", {
                                "class": "aiondb-link-icon",
                                css: {width: a.opt.iconSize, height: a.opt.iconSize}
                            }).append(k("<img />", {src: "//" + this.host + "/upload/images/icon/transform/" + l.icon_name + ".png"}));
                            a.opt.addIcon && a.opt.replaceText ? b.html(h.add(k("<span />", {text: l.desc}))) : a.opt.replaceText ? b.html(k("<span />", {text: l.desc})) : h.prependTo(b)
                        }
                    })
                }
            })
        }, style: function (h) {
            0 < k("style#" + h.hash).length || t.append(k("<style />", {id: h.hash, text: h.text, type: "text/css"}))
        }
    };
    r.prototype = {
        tab: function (h, b) {
            b = b || h.originalEvent.wheelDelta;
            var a = this.target;
            if (!h.shiftKey) return !0;
            var k = 0 > b ? a.find(".tab-button-block .tab-list a.active").next() : a.find(".tab-button-block .tab-list a.active").prev();
            if (0 >= k.length) return !1;
            k.addClass("active").siblings("a.active").removeClass("active");
            a.find(k.attr("href")).addClass("active").siblings("div.content-tab.active").removeClass("active");
            this._reallocation(h)
        }, show: function (h) {
            var b = this.hash, a = this.link, m = this.target, l = k(this.link).data("aiondb"), n = this._adb;
            n._data[a.host] = n._data[a.host] || {};
            m.data("aiondb", {item: "skills" === l.type ? this.item.code : this.item.id});
            b in n._data[a.host] && ("error" in n._data[a.host][b] || !("content" in n._data[a.host][b])) || (b in n._data[a.host] ? this._show(h) : this._get(h))
        }, hide: function (h) {
            h.shiftKey || this.target.removeData("aiondb").hide().empty()
        }, move: function (h) {
            this._reallocation(h)
        }, _get: function (h) {
            var b = {}, a = this, m = this.hash, l = k(this.link).data("aiondb"), n = this._adb;
            b.section = l.type;
            "skills" === l.type ? (b["class"] = a.item["class"],
                b.item = a.item.code) : b.item = a.item.id;
            k.ajax("https://" + a.link.host + "/syndication/view/?lang="+n.opt.lang, {
                data: b,
                type: "get",
                dataType: "json",
                success: function (b) {
                    !("error" in b) && "content" in b && (n._data[a.link.host][m] = b, a._show(h))
                }
            })
        }, _show: function (h) {
            var b = this.hash, a = this.link, m = this.target, l = k(this.link).data("aiondb"),
                n = k(this.target).data("aiondb");
            l = "skills" === l.type ? this.item.code : this.item.id;
            void 0 !== n && l === n.item && (m.html(this._adb._data[a.host][b].content).show(), m.find(".tab-button-block .tab-list a").click(function (a) {
                if (!a.shiftKey ||
                    k(this).hasClass("active")) return !1;
                k(this).addClass("active").siblings("a.active").removeClass("active");
                k(k(this).attr("href")).addClass("active").siblings("div.content-tab.active").removeClass("active");
                return !1
            }), this._reallocation(h))
        }, _reallocation: function (h) {
            var b = {top: 0, left: 0}, a = this.target, k = t.outerWidth(), l = a.outerWidth(), n = t.outerHeight(),
                p = a.outerHeight();
            b.top += h.pageY + p + 20 > n ? p > h.pageY ? 2 : h.pageY - (p + 5) : h.pageY + 20;
            b.left += h.pageX + l + 20 > k ? l > h.pageX ? 2 : h.pageX - (l + 5) : h.pageX + 20;
            a.css(b)
        }
    };
    k.fn.aionDBSyndication = function (h) {
        if (0 >= this.length) return this;
        h = h || {};
        var b = y(JSON.stringify(h));
        b in u || (u[b] = new w(this, h));
        return u[b].elements
    };
    k(function () {
        t = k("body");
        t.append(v)
    })
})(jQuery);