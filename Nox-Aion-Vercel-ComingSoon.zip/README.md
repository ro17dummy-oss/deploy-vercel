# Deployment ke Vercel (Ready-to-Deploy)

Paket ini sudah dikonfigurasi khusus untuk dideploy langsung ke **Vercel** tanpa konfigurasi tambahan.

## Struktur File
```text
├── index.html         # Landing Page Coming Soon
├── vercel.json        # Konfigurasi caching aset & clean URLs Vercel
└── assets/
    └── aion20/
        ├── home.js
        ├── assets/    # Logo, video latar belakang, dan gambar poster
        └── styles/    # CSS animasi, layout, dan 4-phase progress bar
```

---

## Cara Deploy (Pilih salah satu)

### Opsi 1 — Menggunakan Vercel CLI (Super Cepat)
1. Ekstrak file ZIP ini ke komputer Anda.
2. Buka folder hasil ekstrak di Terminal / Command Prompt (CMD).
3. Jalankan perintah:
   ```bash
   npx vercel
   ```
4. Tekan Enter untuk menyetujui opsi default (atau login jika diminta).
5. Untuk menjadikannya domain live utama:
   ```bash
   npx vercel --prod
   ```

---

### Opsi 2 — Upload via GitHub & Web Dashboard Vercel
1. Ekstrak ZIP ini lalu push seluruh isinya ke sebuah repository GitHub baru.
2. Buka [vercel.com](https://vercel.com) → klik **Add New Project**.
3. Import repository GitHub tersebut.
4. Pada pilihan **Framework Preset**, pilih **Other**.
5. Klik **Deploy**.
